class BankAccount:
    def __init__(self, account_number, account_holder_name, initial_balance=0.0):
        self._account_number = account_number
        self._account_holder_name = account_holder_name
        self._account_balance = initial_balance

    def deposit(self, amount):
        if amount > 0:
            self._account_balance += amount
            print("Deposited {}. New balance: {}".format(amount, self._account_balance))
        else:
            print("Invalid deposit amount.")

    def withdraw(self, amount):
        if amount > 0 and amount <= self._account_balance:
            self._account_balance -= amount
            print("Withdrawn {}. New balance: {}".format(amount, self._account_balance))
        else:
            print("Invalid withdrawal amount or insufficient balance.")

    def display_balance(self):
        print("Account balance for {} (Account #{}): {}".format(self._account_holder_name, self._account_number, self._account_balance))


# Create an instance of BankAccount
myaccount = BankAccount(account_number="123456789", account_holder_name="Anto", initial_balance=1000)

# Withdraw and deposit
myaccount.withdraw(500)
myaccount.deposit(100000)

# Display balance
myaccount.display_balance()